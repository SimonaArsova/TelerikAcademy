﻿namespace ClassChef
{
    class Carrot: Vegetable
    {
    }
}
