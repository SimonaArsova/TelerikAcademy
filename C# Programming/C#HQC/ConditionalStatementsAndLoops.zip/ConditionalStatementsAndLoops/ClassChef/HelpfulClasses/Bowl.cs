﻿namespace ClassChef
{
    using System;

    public class Bowl
    {
        public void Add(Vegetable vegitable)
        {
            throw new NotImplementedException();
        }
    }
}
