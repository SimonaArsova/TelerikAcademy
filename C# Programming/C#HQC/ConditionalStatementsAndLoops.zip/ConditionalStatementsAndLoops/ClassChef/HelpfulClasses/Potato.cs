﻿namespace ClassChef
{
    public class Potato: Vegetable
    {
    }
}
