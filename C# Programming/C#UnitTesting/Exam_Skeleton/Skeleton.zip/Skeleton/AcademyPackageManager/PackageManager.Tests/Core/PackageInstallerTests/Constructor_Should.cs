﻿using Moq;
using NUnit.Framework;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Repositories.Contracts;
using PackageManager.Tests.Core.PackageInstallerTests.Fakes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Core.PackageInstallerTests
{
    [TestFixture]
    class Constructor_Should
    {
        //[Test]
        //public void SetProjectValue_WhenValueIsValid()
        //{
        //    var downloaderMock = new Mock<IDownloader>();
        //    var projectMock = new Mock<IProject>();
        //    var packageRepository = new Mock<IRepository<IPackage>>();

        //    var packageInstaller = new PackageInstallerFake(downloaderMock.Object, projectMock.Object);

        //    Assert.AreEqual(downloaderMock.Object, packageInstaller.DownloaderFake);
        //}

    }
}
